<?php

use Illuminate\Database\Seeder;

class help extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}
